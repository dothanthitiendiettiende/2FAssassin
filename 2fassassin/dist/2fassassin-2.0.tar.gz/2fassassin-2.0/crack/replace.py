#!/usr/bin/env python


# replace the original private key on the remote server
# update authorized_keys
