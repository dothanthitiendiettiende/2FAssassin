#!/usr/bin/env python


#def hashsum():
    
