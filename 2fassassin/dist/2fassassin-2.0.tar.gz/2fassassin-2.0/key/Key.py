class Key:

    def _init_(self, filename, status): # status = ciphered or not
        self.filename = filename
        self.status = status
# to be resumed ........
